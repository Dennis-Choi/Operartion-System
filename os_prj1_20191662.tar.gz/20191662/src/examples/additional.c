#include <stdio.h>
#include <syscall.h>
#include <stdlib.h>

int main(int argc,char *argv[]){
    int num[4];
    if(argc!=5){
        return EXIT_FAILURE;
    }
    /* argv를 int에 저장 */
    for(int i=1;i<5;i++){
        num[i-1]=atoi(argv[i]);
    }
    int fibo_result=fibonacci(num[0]);
    int max_result=max_of_four_int(num[0],num[1],num[2],num[3]);
    printf("%d %d\n",fibo_result,max_result);
    return EXIT_SUCCESS;
}
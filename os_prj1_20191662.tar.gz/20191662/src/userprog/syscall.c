#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h" // 추가
static void syscall_handler (struct intr_frame *);

/* system call function */
int halt(uint32_t *esp);
int exit(uint32_t *esp);
int wait(uint32_t *esp);
int exec(uint32_t *esp);
int write(uint32_t *esp);
int read(uint32_t *esp);
int fibo(uint32_t *esp);
int max_four(uint32_t *esp);


void init(int *arg_num){
  arg_num[SYS_HALT]=0;
  arg_num[SYS_EXIT]=1;
  arg_num[SYS_WAIT]=1;
  arg_num[SYS_EXEC]=1;
  arg_num[SYS_WRITE]=3;
  arg_num[SYS_READ]=3;
  arg_num[SYS_FIBO]=1;
  arg_num[SYS_MAXFOUR]=4;
}
/*esp를 탐색하며 해당 주소가 user_addr로 valid한 주소인지 탐색하는 함수 */
void is_addr_valid(uint32_t *esp, int n){
  for(int i=0; i<=n;i++){
    if(!is_user_vaddr((void*)(esp+4*i)))exit(-1);
  }
}
void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f ) 
{
  uint32_t *esp = (uint32_t *)f->esp;
  int arg_num[22]={0,};
  init(arg_num);
  is_addr_valid(esp,arg_num[*esp]);
  switch(*esp){
    case SYS_HALT:halt(esp);break;
    case SYS_EXIT:exit(esp);break;
    case SYS_WAIT:f->eax=wait(esp);break;
    case SYS_EXEC:f->eax=exec(esp);break;
    case SYS_WRITE:f->eax=write(esp);break;
    case SYS_READ:f->eax=read(esp);break;
    case SYS_FIBO:f->eax=fibo(esp);break;
    case SYS_MAXFOUR:f->eax=max_four(esp);break;
  }
}

int halt(uint32_t *esp){
  shutdown_power_off();
  return 0;
}
int exit(uint32_t *esp){
  int status=-1;
  int i;
  char parse_name[256];

  /* status 저장 */
  if(esp!=-1){
    status=(int)esp[1];
  }
  /* 쓰레드의 이름만 순수하게 찾기 */
  for(i=0;i<strlen(thread_name())+1;i++){
    if(thread_name()[i]==' ')break;
  }
  strlcpy(parse_name,thread_name(),i+1);
  /* print  and Thread 상태 업데이트 이후 exit*/
  printf("%s: exit(%d)\n",parse_name,status);
  thread_current()->exit_status=status;
  thread_exit();
  return 0;
}
int wait(uint32_t *esp){
  return process_wait((int)esp[1]);
}
int exec(uint32_t *esp){
  return process_execute((char *)esp[1]);
}
int write(uint32_t *esp){
  /* 변수 설정 */
  int f = (int)esp[1];
  void *buf=(void*)esp[2];
  unsigned size=(int)esp[3];
  /* write */
  if(f==1){ //STDOUT
    putbuf(buf,size);return size;
  }
  return -1;
}
int read(uint32_t *esp){
  /* 변수 설정 */
  int f = (int)esp[1];
  void *buf=(void*)esp[2];
  unsigned size=(int)esp[3];
  if(f==0){ //STDIN
    int i; 
    for(i=0;input_getc()||i<=size;++i){}
    return i;
  }
  return -1;
}
int fibo(uint32_t *esp){
  /* 변수 설정 */
  int n=(int)esp[1];
  int result=0;
  int tmp1=0;
  int tmp2=1;
  for(int i=0;i<n;i++){
    tmp1=result+tmp2;
    result=tmp2;
    tmp2=tmp1;
  }
  return result;
}
int max_four(uint32_t *esp){
  int max=0;
  for(int i=1;i<=4;i++){
    if(max<(int)esp[i])max=(int)esp[i];
  }
  return max;
}
